const service = require('../services/clienteService');

module.exports = {
  getAll: async (req, res) => {
    const clientes = await service.listarClientes();
    res.json(clientes[0]);
  },
  getById: async (req, res) => {
    const cliente = await service.buscarCliente(req.params.id);
    res.json(cliente[0]);
  },
  create: async (req, res) => {
    const resultado = await service.criarCliente(req.body);
    res.json({ id: resultado[0].insertId });
  },
};
