const service = require('../services/produtoService');

module.exports = {
  getAll: async (req, res) => {
    const produtos = await service.listarProdutos();
    res.json(produtos[0]);
  },
  getById: async (req, res) => {
    const produto = await service.buscarProduto(req.params.id);
    res.json(produto[0]);
  },
  create: async (req, res) => {
    const resultado = await service.criarProduto(req.body);
    res.json({ id: resultado[0].insertId });
  },
};
