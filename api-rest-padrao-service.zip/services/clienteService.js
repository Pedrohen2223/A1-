const clienteRepo = require('../repositories/clienteRepository');

module.exports = {
  listarClientes: async () => await clienteRepo.getAll(),
  buscarCliente: async (id) => await clienteRepo.getById(id),
  criarCliente: async (cliente) => await clienteRepo.create(cliente),
};
