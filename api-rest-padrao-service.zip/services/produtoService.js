const produtoRepo = require('../repositories/produtoRepository');

module.exports = {
  listarProdutos: async () => await produtoRepo.getAll(),
  buscarProduto: async (id) => await produtoRepo.getById(id),
  criarProduto: async (produto) => await produtoRepo.create(produto),
};
