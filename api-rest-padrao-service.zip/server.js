const express = require('express');
const app = express();
const produtoRoutes = require('./routes/produtoRoutes');
const clienteRoutes = require('./routes/clienteRoutes');

app.use(express.json());

app.use('/produtos', produtoRoutes);
app.use('/clientes', clienteRoutes);

app.listen(3000, () => {
  console.log('API rodando na porta 3000');
});
