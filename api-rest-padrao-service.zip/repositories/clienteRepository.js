const db = require('../db');

module.exports = {
  getAll: () => db.query('SELECT * FROM cliente'),
  getById: (id) => db.query('SELECT * FROM cliente WHERE id = ?', [id]),
  create: (cliente) => db.query('INSERT INTO cliente SET ?', [cliente]),
};
