const db = require('../db');

module.exports = {
  getAll: () => db.query('SELECT * FROM produto'),
  getById: (id) => db.query('SELECT * FROM produto WHERE id = ?', [id]),
  create: (produto) => db.query('INSERT INTO produto SET ?', [produto]),
};
